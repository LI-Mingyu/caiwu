
//您OA系统地址，必须/结尾哦
apiurl 			= 'http://ds.cicqeg.com/';

//默认的标题
systemtitle 	= '中投OA';

//登录页上是否显示设置系统地址，设置true显示，false不显示
logincogbool 	= true;

//登录页上底部版权
loginstring		= 'Copyright © 2019 中投OA系统 ds.cicqeg.com';

//小米推送，这个是设置安卓的，IOS需要到文件res/Info.plist下设置，自己到小米推送服务平台下获取
xiaomi_appId  	= '';
xiaomi_appKey 	= '';