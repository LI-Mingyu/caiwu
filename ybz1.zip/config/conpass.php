<?php 

$server="127.0.0.1";

$dbuser='ybz';


$dbpass="Ybz58.com";


$db_base='yibenzhang';

?>